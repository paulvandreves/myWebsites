﻿var name = "paul";

alert(name); 

